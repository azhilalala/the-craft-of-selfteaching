# The Python Tutorial epub/html/ipynb

Original URI:

> https://docs.python.org/3/tutorial/

Source from:

> https://github.com/python/cpython/tree/master/Doc/tutorial

html/epub converted by Sphinx

> http://www.sphinx-doc.org

ipynb converted by rst2ipynb

> https://pypi.org/project/rst2ipynb/